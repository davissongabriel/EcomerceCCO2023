﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EcommerceCCO2023.Models
{
    public class Itens_Pedido
    {
        public int Quantidade { get; set; }
        public decimal Valor { get; set; }

        public int IdProduto { get; set; }
        public Produto Produto { get; set; }

        public int IdPedido { get; set; }
        public Pedido Pedido { get; set; }

        public Itens_Pedido()
        {
            Produto = new Produto();
        }

        public decimal ValorTotal
        {
            get
            {
                return Quantidade * Valor;
            }
        }
    }
}
